import { StatusBar } from 'expo-status-bar';
import { Pressable, Text, View } from 'react-native';
import { Button } from 'react-native-web';
import { useNavigation } from '@react-navigation/native';
import * as Animatable from 'react-native-animatable';
import styles from './style';

export default function Home() {
  const navigation = useNavigation();

  return (
    <View style={(styles.container)} >
      <StatusBar style="auto" />
        <Animatable.Text style={styles.texto} animation="fadeIn" duration={3000}> Bem Vindo Ao Zoológico</Animatable.Text>
        <View style={styles.botaoArea}>
        <Pressable style={styles.button}
        onPress={ () => navigation.navigate('Territorios')}>
          <Text>Entrar</Text>
        </Pressable>
        </View>
    </View>
  );
}