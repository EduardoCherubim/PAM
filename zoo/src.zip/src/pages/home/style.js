import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#828282',
      justifyContent:'center',
      alignItens:'center'
    },
    texto:{
      alignSelf:'center',
      marginBottom:'25%',
      fontSize:30
    },
    botaoArea:{
      width:'50%',
      alignSelf:'center'
    },
    button:{
      height:'100%',
      width:'100%'
    }
  
  });