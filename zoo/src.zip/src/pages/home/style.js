import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#828282',
      justifyContent:'center',
      alignItens:'center'
    },
    texto:{
      alignSelf:'center',
      marginBottom:'25%',
      fontSize:30
    }
  
  });