import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#828282',
      justifyContent:'center',
      alignItens:'center'
    },
    icon: {
        flex:1,
        alignSelf:'center',
        justifyContent:'center'
    },
    text: {
        alignSelf:'center',
        fontSize:20,
    }

});