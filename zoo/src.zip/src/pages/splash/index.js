import { StatusBar } from 'expo-status-bar';
import { Pressable, Text, View } from 'react-native';
import { Image } from 'react-native-web';
import { useNavigation } from '@react-navigation/native';
import * as Animatable from 'react-native-animatable';
import styles from './style';

export default function Home() {
    const navigation = useNavigation();
  
    return (
    <View style={(styles.container)} >
      <StatusBar style="auto" />
        <Pressable onPress={ () => navigation.navigate('Login')} style={styles.icon}>
        <Image style={{width:300,height:300}}
              source={{uri:'https://i.pinimg.com/originals/41/8c/09/418c090ec164c7d3d18a5f27dbb81eb1.gif'}} />
            <Text style={styles.text}>Carregando</Text>
        </Pressable>
    </View>
  );
}