import { StatusBar } from 'expo-status-bar';
import { Pressable, Text, View } from 'react-native';
import { TextInput} from 'react-native-web'
import * as Animatable from 'react-native-animatable';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from './style';
import { useState } from 'react';

export default function Login() {
  const navigation = useNavigation();
  const [email, setEmail] = useState();
  const [senha, setSenha] = useState();

  const teste = async () => {
    try {
      const emailTeste = await AsyncStorage.getItem('email');
      const senhaTeste = await AsyncStorage.getItem('senha');
  
      if (emailTeste === email && senhaTeste === senha) {
        navigation.navigate('Home');
      } else {
        alert('Usuário ou senha errados!');
      }
    } catch (error) {
      console.error('Erro ao verificar os dados:', error);
      alert('Ocorreu um erro ao tentar realizar o login.');
    }
  }
  return (
    <View style={styles.container}>
        <Animatable.View style={styles.inputArea} animation="fadeInLeft" duration={5000}>
        <Text style={styles.textInput}>E-mail</Text>
        <TextInput
        style={styles.input}
        value={email}
        onChangeText={(text) => setEmail(text)}
        />
        </Animatable.View>

        <Animatable.View style={styles.inputArea} animation="fadeInLeft" duration={6000}>
        <Text style={styles.textInput}>Senha</Text>
        <TextInput
        style={styles.input}
        value={senha}
        onChangeText={(text) => setSenha(text)}
        />
      </Animatable.View>

      <Animatable.View style={styles.buttonArea} animation="fadeIn" duration={4000}>

        <Pressable style={styles.button}
        onPress={ () => navigation.navigate('Cadastro')}>
          <Text>Não tenho conta</Text>
        </Pressable>

        <Pressable style={styles.button}
        onPress={teste}> 
          <Text>Entrar</Text>
        </Pressable>

      </Animatable.View>
      <StatusBar style="auto" />
    </View>
  );
}