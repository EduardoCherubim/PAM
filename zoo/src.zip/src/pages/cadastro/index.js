import { StatusBar } from 'expo-status-bar';
import { Pressable, Text, View } from 'react-native';
import { TextInput } from 'react-native-web';
import * as Animatable from 'react-native-animatable';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from './style';
import { useState } from 'react';

export default function Cadastro() {
  const navigation = useNavigation();
  const [nome, setNome] = useState();
  const [telefone, setTelefone] = useState();
  const [idade, setIdade] = useState();
  const [email, setEmail] = useState();
  const [senha, setSenha] = useState();

  const salvarDados = async () => {
    try {
      await AsyncStorage.setItem('nome', nome);
      await AsyncStorage.setItem('telefone', telefone);
      await AsyncStorage.setItem('idade', idade.toString());
      await AsyncStorage.setItem('email', email);
      await AsyncStorage.setItem('senha', senha);
      alert('Dados salvos com sucesso!');
      navigation.navigate('Login');
    } catch (error) {
      console.error('Erro ao salvar os dados:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Animatable.View style={styles.inputArea} animation="fadeInLeft" duration={2000}>
        <Text style={styles.textInput}>Nome</Text>
        <TextInput 
        value={nome} 
        style={styles.input} 
        onChangeText={(text) => setNome(text)} 
        />
      </Animatable.View>

      <Animatable.View style={styles.inputArea} animation="fadeInLeft" duration={3000}>
        <Text style={styles.textInput}>Idade</Text>
        <TextInput 
        value={idade} 
        style={styles.input} 
        onChangeText={(text) => setIdade(text)} 
        />
      </Animatable.View>

      <Animatable.View style={styles.inputArea} animation="fadeInLeft" duration={4000}>
        <Text style={styles.textInput}>Telefone</Text>
        <TextInput 
        value={telefone} 
        style={styles.input} 
        onChangeText={(text) => setTelefone(text)} 
        />
      </Animatable.View>

      <Animatable.View style={styles.inputArea} animation="fadeInLeft" duration={5000}>
        <Text style={styles.textInput}>E-mail</Text>
        <TextInput 
        value={email} 
        style={styles.input} 
        onChangeText={(text) => setEmail(text)} 
        />
      </Animatable.View>

      <Animatable.View style={styles.inputArea} animation="fadeInLeft" duration={6000}>
        <Text style={styles.textInput}>Senha</Text>
        <TextInput 
        value={senha} 
        style={styles.input} 
        onChangeText={(text) => setSenha(text)} 
        />
      </Animatable.View>

      <Animatable.View style={styles.buttonArea} animation="fadeIn" duration={4000}>
        <Pressable style={styles.button} onPress={salvarDados}>
          <Text>Cadastrar</Text>
        </Pressable>
      </Animatable.View>
      <StatusBar style="auto" />
    </View>
  );
}
